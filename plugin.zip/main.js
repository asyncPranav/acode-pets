"use strict";(()=>{var y="com.asyncpranav.acodepets",f={cat:{skins:{orange:{body:"#f4a460",dark:"#e8935a",ear:"#ffb6c1"},grey:{body:"#9e9e9e",dark:"#757575",ear:"#f8bbd0"},black:{body:"#333333",dark:"#1a1a1a",ear:"#ff80ab"},white:{body:"#f5f5f5",dark:"#e0e0e0",ear:"#fce4ec"},cream:{body:"#ffe0b2",dark:"#ffcc80",ear:"#f8bbd0"}},frames:{idle:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="22" rx="9" ry="7" fill="${e.body}"/>
        <circle cx="16" cy="13" r="7" fill="${e.body}"/>
        <polygon points="10,8 7,2 13,7" fill="${e.body}"/>
        <polygon points="22,8 25,2 19,7" fill="${e.body}"/>
        <polygon points="10,8 8,4 12,7" fill="${e.ear}"/>
        <polygon points="22,8 24,4 20,7" fill="${e.ear}"/>
        <ellipse cx="13" cy="12" rx="2" ry="2.5" fill="#2d2d2d"/>
        <ellipse cx="19" cy="12" rx="2" ry="2.5" fill="#2d2d2d"/>
        <circle cx="13.7" cy="11.3" r="0.6" fill="white"/>
        <circle cx="19.7" cy="11.3" r="0.6" fill="white"/>
        <ellipse cx="16" cy="14.5" rx="1" ry="0.7" fill="#ff9999"/>
        <path d="M14.5 15.2 Q16 16.5 17.5 15.2" stroke="#cc6666" stroke-width="0.5" fill="none"/>
        <line x1="8" y1="14" x2="13" y2="14.5" stroke="#888" stroke-width="0.4"/>
        <line x1="8" y1="15.5" x2="13" y2="15.2" stroke="#888" stroke-width="0.4"/>
        <line x1="19" y1="14.5" x2="24" y2="14" stroke="#888" stroke-width="0.4"/>
        <line x1="19" y1="15.2" x2="24" y2="15.5" stroke="#888" stroke-width="0.4"/>
        <path d="M25 22 Q30 18 28 14" stroke="${e.body}" stroke-width="2.5" fill="none" stroke-linecap="round"/>
        <ellipse cx="11" cy="27" rx="2.5" ry="2" fill="${e.dark}"/>
        <ellipse cx="21" cy="27" rx="2.5" ry="2" fill="${e.dark}"/>
      </svg>`,walk:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="22" rx="9" ry="6" fill="${e.body}"/>
        <circle cx="16" cy="13" r="7" fill="${e.body}"/>
        <polygon points="10,8 7,2 13,7" fill="${e.body}"/>
        <polygon points="22,8 25,2 19,7" fill="${e.body}"/>
        <polygon points="10,8 8,4 12,7" fill="${e.ear}"/>
        <polygon points="22,8 24,4 20,7" fill="${e.ear}"/>
        <ellipse cx="13" cy="12" rx="2" ry="2.5" fill="#2d2d2d"/>
        <ellipse cx="19" cy="12" rx="2" ry="2.5" fill="#2d2d2d"/>
        <circle cx="13.7" cy="11.3" r="0.6" fill="white"/>
        <circle cx="19.7" cy="11.3" r="0.6" fill="white"/>
        <ellipse cx="16" cy="14.5" rx="1" ry="0.7" fill="#ff9999"/>
        <path d="M14.5 15.2 Q16 16.5 17.5 15.2" stroke="#cc6666" stroke-width="0.5" fill="none"/>
        <line x1="8" y1="14" x2="13" y2="14.5" stroke="#888" stroke-width="0.4"/>
        <line x1="19" y1="14.5" x2="24" y2="14" stroke="#888" stroke-width="0.4"/>
        <path d="M25 21 Q31 15 27 11" stroke="${e.body}" stroke-width="2.5" fill="none" stroke-linecap="round"/>
        <ellipse cx="10" cy="28" rx="2.5" ry="1.8" fill="${e.dark}" transform="rotate(-15,10,28)"/>
        <ellipse cx="20" cy="26" rx="2.5" ry="1.8" fill="${e.dark}" transform="rotate(15,20,26)"/>
        <ellipse cx="13" cy="26" rx="2" ry="1.8" fill="${e.dark}" transform="rotate(10,13,26)"/>
        <ellipse cx="22" cy="28" rx="2" ry="1.8" fill="${e.dark}" transform="rotate(-10,22,28)"/>
      </svg>`,run:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="21" rx="10" ry="5.5" fill="${e.body}" transform="rotate(-10,16,21)"/>
        <circle cx="16" cy="12" r="7" fill="${e.body}"/>
        <polygon points="10,7 7,1 13,6" fill="${e.body}"/>
        <polygon points="22,7 25,1 19,6" fill="${e.body}"/>
        <polygon points="10,7 8,3 12,6" fill="${e.ear}"/>
        <polygon points="22,7 24,3 20,6" fill="${e.ear}"/>
        <ellipse cx="13" cy="11" rx="2" ry="2.5" fill="#2d2d2d"/>
        <ellipse cx="19" cy="11" rx="2" ry="2.5" fill="#2d2d2d"/>
        <circle cx="13.7" cy="10.3" r="0.6" fill="white"/>
        <circle cx="19.7" cy="10.3" r="0.6" fill="white"/>
        <ellipse cx="16" cy="13.5" rx="1" ry="0.7" fill="#ff9999"/>
        <line x1="8" y1="13" x2="13" y2="13.5" stroke="#888" stroke-width="0.4"/>
        <line x1="19" y1="13.5" x2="24" y2="13" stroke="#888" stroke-width="0.4"/>
        <path d="M25 20 Q32 18 31 14" stroke="${e.body}" stroke-width="2.5" fill="none" stroke-linecap="round"/>
        <ellipse cx="8" cy="26" rx="2.5" ry="1.5" fill="${e.dark}" transform="rotate(-30,8,26)"/>
        <ellipse cx="14" cy="28" rx="2.5" ry="1.5" fill="${e.dark}" transform="rotate(20,14,28)"/>
        <ellipse cx="19" cy="25" rx="2.5" ry="1.5" fill="${e.dark}" transform="rotate(-20,19,25)"/>
        <ellipse cx="25" cy="27" rx="2.5" ry="1.5" fill="${e.dark}" transform="rotate(30,25,27)"/>
      </svg>`,sleep:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="17" cy="23" rx="10" ry="6" fill="${e.body}"/>
        <circle cx="11" cy="20" r="6" fill="${e.body}"/>
        <polygon points="7,15 5,10 10,14" fill="${e.body}"/>
        <polygon points="14,15 16,10 11,14" fill="${e.body}"/>
        <polygon points="7,15 6,12 9,14" fill="${e.ear}"/>
        <polygon points="14,15 15,12 12,14" fill="${e.ear}"/>
        <path d="M9 19.5 Q11 18.5 13 19.5" stroke="#2d2d2d" stroke-width="1" fill="none" stroke-linecap="round"/>
        <text x="19" y="14" font-size="5" fill="#888" font-family="sans-serif">z</text>
        <text x="22" y="10" font-size="6" fill="#888" font-family="sans-serif">z</text>
        <text x="25" y="6"  font-size="7" fill="#888" font-family="sans-serif">Z</text>
        <path d="M27 23 Q30 20 27 17 Q24 14 26 20" stroke="${e.body}" stroke-width="2.5" fill="none" stroke-linecap="round"/>
      </svg>`,jump:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="18" rx="9" ry="6" fill="${e.body}" transform="rotate(-20,16,18)"/>
        <circle cx="16" cy="9" r="7" fill="${e.body}"/>
        <polygon points="10,4 7,-2 13,3" fill="${e.body}"/>
        <polygon points="22,4 25,-2 19,3" fill="${e.body}"/>
        <polygon points="10,4 8,0 12,3" fill="${e.ear}"/>
        <polygon points="22,4 24,0 20,3" fill="${e.ear}"/>
        <ellipse cx="13" cy="8" rx="2" ry="2.5" fill="#2d2d2d"/>
        <ellipse cx="19" cy="8" rx="2" ry="2.5" fill="#2d2d2d"/>
        <circle cx="13.7" cy="7.3" r="0.6" fill="white"/>
        <circle cx="19.7" cy="7.3" r="0.6" fill="white"/>
        <ellipse cx="16" cy="10.5" rx="1" ry="0.7" fill="#ff9999"/>
        <path d="M14.5 11.5 Q16 13 17.5 11.5" stroke="#cc6666" stroke-width="0.5" fill="none"/>
        <path d="M25 17 Q32 13 30 7" stroke="${e.body}" stroke-width="2.5" fill="none" stroke-linecap="round"/>
        <ellipse cx="8" cy="24" rx="2.5" ry="1.5" fill="${e.dark}" transform="rotate(-40,8,24)"/>
        <ellipse cx="13" cy="27" rx="2.5" ry="1.5" fill="${e.dark}" transform="rotate(30,13,27)"/>
        <ellipse cx="20" cy="26" rx="2.5" ry="1.5" fill="${e.dark}" transform="rotate(-25,20,26)"/>
        <ellipse cx="25" cy="23" rx="2.5" ry="1.5" fill="${e.dark}" transform="rotate(40,25,23)"/>
        <text x="3" y="8" font-size="8" fill="#FFD700">\u2728</text>
      </svg>`,sit:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <circle cx="16" cy="13" r="7" fill="${e.body}"/>
        <polygon points="10,8 7,2 13,7" fill="${e.body}"/>
        <polygon points="22,8 25,2 19,7" fill="${e.body}"/>
        <polygon points="10,8 8,4 12,7" fill="${e.ear}"/>
        <polygon points="22,8 24,4 20,7" fill="${e.ear}"/>
        <ellipse cx="13" cy="12" rx="2" ry="2.5" fill="#2d2d2d"/>
        <ellipse cx="19" cy="12" rx="2" ry="2.5" fill="#2d2d2d"/>
        <circle cx="13.7" cy="11.3" r="0.6" fill="white"/>
        <circle cx="19.7" cy="11.3" r="0.6" fill="white"/>
        <ellipse cx="16" cy="14.5" rx="1" ry="0.7" fill="#ff9999"/>
        <path d="M14.5 15.2 Q16 16.5 17.5 15.2" stroke="#cc6666" stroke-width="0.5" fill="none"/>
        <line x1="8" y1="14" x2="13" y2="14.5" stroke="#888" stroke-width="0.4"/>
        <line x1="19" y1="14.5" x2="24" y2="14" stroke="#888" stroke-width="0.4"/>
        <ellipse cx="16" cy="25" rx="9" ry="5" fill="${e.dark}"/>
        <path d="M25 22 Q28 26 26 29" stroke="${e.body}" stroke-width="2.5" fill="none" stroke-linecap="round"/>
      </svg>`,happy:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="22" rx="9" ry="7" fill="${e.body}"/>
        <circle cx="16" cy="13" r="7" fill="${e.body}"/>
        <polygon points="10,8 7,2 13,7" fill="${e.body}"/>
        <polygon points="22,8 25,2 19,7" fill="${e.body}"/>
        <polygon points="10,8 8,4 12,7" fill="${e.ear}"/>
        <polygon points="22,8 24,4 20,7" fill="${e.ear}"/>
        <path d="M11 11 Q13 9.5 15 11" stroke="#2d2d2d" stroke-width="1.2" fill="none" stroke-linecap="round"/>
        <path d="M17 11 Q19 9.5 21 11" stroke="#2d2d2d" stroke-width="1.2" fill="none" stroke-linecap="round"/>
        <ellipse cx="16" cy="14.5" rx="1" ry="0.7" fill="#ff9999"/>
        <path d="M13.5 15.5 Q16 18 18.5 15.5" stroke="#cc6666" stroke-width="0.8" fill="none"/>
        <ellipse cx="16" cy="17" rx="2" ry="1.2" fill="#ff6b8a"/>
        <line x1="8" y1="14" x2="13" y2="14.5" stroke="#888" stroke-width="0.4"/>
        <line x1="19" y1="14.5" x2="24" y2="14" stroke="#888" stroke-width="0.4"/>
        <path d="M25 22 Q30 16 27 11" stroke="${e.body}" stroke-width="2.5" fill="none" stroke-linecap="round"/>
        <ellipse cx="11" cy="27" rx="2.5" ry="2" fill="${e.dark}"/>
        <ellipse cx="21" cy="27" rx="2.5" ry="2" fill="${e.dark}"/>
        <text x="1" y="10" font-size="7" fill="#FF69B4">\u2661</text>
        <text x="24" y="8" font-size="6" fill="#FFD700">\u2605</text>
      </svg>`}},dog:{skins:{brown:{body:"#d2a679",dark:"#c49060",ear:"#b8864e"},golden:{body:"#ffc87a",dark:"#e8a855",ear:"#d4883a"},white:{body:"#f5f5f5",dark:"#e0e0e0",ear:"#ccc"},black:{body:"#333",dark:"#1a1a1a",ear:"#222"},spot:{body:"#f5f5f5",dark:"#333",ear:"#ccc"}},frames:{idle:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="22" rx="10" ry="7" fill="${e.body}"/>
        <circle cx="16" cy="12" r="8" fill="${e.body}"/>
        <ellipse cx="9" cy="14" rx="3" ry="5" fill="${e.ear}" transform="rotate(15,9,14)"/>
        <ellipse cx="23" cy="14" rx="3" ry="5" fill="${e.ear}" transform="rotate(-15,23,14)"/>
        <ellipse cx="16" cy="15" rx="4" ry="3" fill="${e.dark}"/>
        <circle cx="13" cy="10" r="2.2" fill="#2d2d2d"/>
        <circle cx="19" cy="10" r="2.2" fill="#2d2d2d"/>
        <circle cx="13.7" cy="9.3" r="0.7" fill="white"/>
        <circle cx="19.7" cy="9.3" r="0.7" fill="white"/>
        <ellipse cx="16" cy="14" rx="1.5" ry="1" fill="#1a1a1a"/>
        <path d="M14 15.5 Q16 17 18 15.5" stroke="#8b5e3c" stroke-width="0.6" fill="none"/>
        <ellipse cx="16" cy="17" rx="1.5" ry="1.2" fill="#ff6b8a"/>
        <path d="M26 20 Q31 15 29 11" stroke="${e.body}" stroke-width="3" fill="none" stroke-linecap="round"/>
        <ellipse cx="11" cy="27" rx="3" ry="2" fill="${e.dark}"/>
        <ellipse cx="21" cy="27" rx="3" ry="2" fill="${e.dark}"/>
      </svg>`,walk:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="22" rx="10" ry="6.5" fill="${e.body}"/>
        <circle cx="16" cy="12" r="8" fill="${e.body}"/>
        <ellipse cx="9" cy="14" rx="3" ry="5" fill="${e.ear}" transform="rotate(15,9,14)"/>
        <ellipse cx="23" cy="14" rx="3" ry="5" fill="${e.ear}" transform="rotate(-15,23,14)"/>
        <ellipse cx="16" cy="15" rx="4" ry="3" fill="${e.dark}"/>
        <circle cx="13" cy="10" r="2.2" fill="#2d2d2d"/>
        <circle cx="19" cy="10" r="2.2" fill="#2d2d2d"/>
        <circle cx="13.7" cy="9.3" r="0.7" fill="white"/>
        <circle cx="19.7" cy="9.3" r="0.7" fill="white"/>
        <ellipse cx="16" cy="14" rx="1.5" ry="1" fill="#1a1a1a"/>
        <path d="M14 15.5 Q16 17 18 15.5" stroke="#8b5e3c" stroke-width="0.6" fill="none"/>
        <ellipse cx="16" cy="17" rx="1.5" ry="1.2" fill="#ff6b8a"/>
        <path d="M26 19 Q32 13 28 9" stroke="${e.body}" stroke-width="3" fill="none" stroke-linecap="round"/>
        <ellipse cx="10" cy="28" rx="3" ry="1.8" fill="${e.dark}" transform="rotate(-15,10,28)"/>
        <ellipse cx="20" cy="26" rx="3" ry="1.8" fill="${e.dark}" transform="rotate(15,20,26)"/>
        <ellipse cx="13" cy="26" rx="2.5" ry="1.8" fill="${e.dark}" transform="rotate(10,13,26)"/>
        <ellipse cx="23" cy="28" rx="2.5" ry="1.8" fill="${e.dark}" transform="rotate(-10,23,28)"/>
      </svg>`,run:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="21" rx="11" ry="5.5" fill="${e.body}" transform="rotate(-8,16,21)"/>
        <circle cx="15" cy="11" r="8" fill="${e.body}"/>
        <ellipse cx="8" cy="13" rx="3" ry="5" fill="${e.ear}" transform="rotate(20,8,13)"/>
        <ellipse cx="22" cy="13" rx="3" ry="5" fill="${e.ear}" transform="rotate(-20,22,13)"/>
        <ellipse cx="15" cy="14" rx="4" ry="3" fill="${e.dark}"/>
        <circle cx="12" cy="9" r="2.2" fill="#2d2d2d"/>
        <circle cx="18" cy="9" r="2.2" fill="#2d2d2d"/>
        <circle cx="12.7" cy="8.3" r="0.7" fill="white"/>
        <circle cx="18.7" cy="8.3" r="0.7" fill="white"/>
        <ellipse cx="15" cy="13" rx="1.5" ry="1" fill="#1a1a1a"/>
        <ellipse cx="15" cy="16" rx="1.5" ry="1.2" fill="#ff6b8a"/>
        <path d="M26 19 Q32 17 31 12" stroke="${e.body}" stroke-width="3" fill="none" stroke-linecap="round"/>
        <ellipse cx="7" cy="26" rx="3" ry="1.5" fill="${e.dark}" transform="rotate(-35,7,26)"/>
        <ellipse cx="14" cy="28" rx="3" ry="1.5" fill="${e.dark}" transform="rotate(20,14,28)"/>
        <ellipse cx="19" cy="25" rx="3" ry="1.5" fill="${e.dark}" transform="rotate(-20,19,25)"/>
        <ellipse cx="26" cy="27" rx="3" ry="1.5" fill="${e.dark}" transform="rotate(35,26,27)"/>
      </svg>`,sleep:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="17" cy="24" rx="11" ry="5.5" fill="${e.body}"/>
        <circle cx="10" cy="20" r="7" fill="${e.body}"/>
        <ellipse cx="5" cy="21" rx="3" ry="4.5" fill="${e.ear}" transform="rotate(20,5,21)"/>
        <ellipse cx="15" cy="21" rx="3" ry="4.5" fill="${e.ear}" transform="rotate(-10,15,21)"/>
        <ellipse cx="10" cy="22" rx="3.5" ry="2.5" fill="${e.dark}"/>
        <path d="M7.5 18.5 Q10 17.5 12.5 18.5" stroke="#2d2d2d" stroke-width="1.2" fill="none" stroke-linecap="round"/>
        <ellipse cx="10" cy="23" rx="1.2" ry="0.8" fill="#1a1a1a"/>
        <text x="18" y="15" font-size="5" fill="#888" font-family="sans-serif">z</text>
        <text x="21" y="11" font-size="6" fill="#888" font-family="sans-serif">z</text>
        <text x="24" y="6"  font-size="7" fill="#888" font-family="sans-serif">Z</text>
      </svg>`,jump:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="17" rx="10" ry="6" fill="${e.body}" transform="rotate(-15,16,17)"/>
        <circle cx="15" cy="8" r="8" fill="${e.body}"/>
        <ellipse cx="8" cy="10" rx="3" ry="5" fill="${e.ear}" transform="rotate(25,8,10)"/>
        <ellipse cx="22" cy="10" rx="3" ry="5" fill="${e.ear}" transform="rotate(-25,22,10)"/>
        <ellipse cx="15" cy="11" rx="4" ry="3" fill="${e.dark}"/>
        <circle cx="12" cy="6" r="2.2" fill="#2d2d2d"/>
        <circle cx="18" cy="6" r="2.2" fill="#2d2d2d"/>
        <circle cx="12.7" cy="5.3" r="0.7" fill="white"/>
        <circle cx="18.7" cy="5.3" r="0.7" fill="white"/>
        <ellipse cx="15" cy="10" rx="1.5" ry="1" fill="#1a1a1a"/>
        <path d="M13 11.5 Q15 13.5 17 11.5" stroke="#8b5e3c" stroke-width="0.6" fill="none"/>
        <ellipse cx="15" cy="14" rx="1.5" ry="1.2" fill="#ff6b8a"/>
        <path d="M25 16 Q32 14 30 8" stroke="${e.body}" stroke-width="3" fill="none" stroke-linecap="round"/>
        <ellipse cx="7" cy="24" rx="3" ry="1.5" fill="${e.dark}" transform="rotate(-40,7,24)"/>
        <ellipse cx="13" cy="27" rx="3" ry="1.5" fill="${e.dark}" transform="rotate(30,13,27)"/>
        <ellipse cx="20" cy="26" rx="3" ry="1.5" fill="${e.dark}" transform="rotate(-25,20,26)"/>
        <ellipse cx="26" cy="23" rx="3" ry="1.5" fill="${e.dark}" transform="rotate(40,26,23)"/>
        <text x="2" y="8" font-size="8" fill="#FFD700">\u2728</text>
      </svg>`,sit:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="25" rx="9" ry="5" fill="${e.dark}"/>
        <circle cx="16" cy="12" r="8" fill="${e.body}"/>
        <ellipse cx="9" cy="14" rx="3" ry="5" fill="${e.ear}" transform="rotate(15,9,14)"/>
        <ellipse cx="23" cy="14" rx="3" ry="5" fill="${e.ear}" transform="rotate(-15,23,14)"/>
        <ellipse cx="16" cy="15" rx="4" ry="3" fill="${e.dark}"/>
        <circle cx="13" cy="10" r="2.2" fill="#2d2d2d"/>
        <circle cx="19" cy="10" r="2.2" fill="#2d2d2d"/>
        <circle cx="13.7" cy="9.3" r="0.7" fill="white"/>
        <circle cx="19.7" cy="9.3" r="0.7" fill="white"/>
        <ellipse cx="16" cy="14" rx="1.5" ry="1" fill="#1a1a1a"/>
        <path d="M14 15.5 Q16 17 18 15.5" stroke="#8b5e3c" stroke-width="0.6" fill="none"/>
        <ellipse cx="16" cy="17" rx="1.5" ry="1.2" fill="#ff6b8a"/>
        <path d="M26 23 Q29 27 27 30" stroke="${e.body}" stroke-width="3" fill="none" stroke-linecap="round"/>
      </svg>`,happy:e=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <ellipse cx="16" cy="22" rx="10" ry="7" fill="${e.body}"/>
        <circle cx="16" cy="12" r="8" fill="${e.body}"/>
        <ellipse cx="9" cy="14" rx="3" ry="5" fill="${e.ear}" transform="rotate(15,9,14)"/>
        <ellipse cx="23" cy="14" rx="3" ry="5" fill="${e.ear}" transform="rotate(-15,23,14)"/>
        <ellipse cx="16" cy="15" rx="4" ry="3" fill="${e.dark}"/>
        <path d="M11 9.5 Q13 8 15 9.5" stroke="#2d2d2d" stroke-width="1.2" fill="none" stroke-linecap="round"/>
        <path d="M17 9.5 Q19 8 21 9.5" stroke="#2d2d2d" stroke-width="1.2" fill="none" stroke-linecap="round"/>
        <ellipse cx="16" cy="14" rx="1.5" ry="1" fill="#1a1a1a"/>
        <path d="M13 15.5 Q16 18.5 19 15.5" stroke="#8b5e3c" stroke-width="0.8" fill="none"/>
        <ellipse cx="16" cy="18" rx="2.5" ry="1.5" fill="#ff6b8a"/>
        <path d="M26 19 Q32 13 28 8" stroke="${e.body}" stroke-width="3" fill="none" stroke-linecap="round"/>
        <ellipse cx="11" cy="27" rx="3" ry="2" fill="${e.dark}"/>
        <ellipse cx="21" cy="27" rx="3" ry="2" fill="${e.dark}"/>
        <text x="1" y="10" font-size="7" fill="#FF69B4">\u2661</text>
        <text x="24" y="8" font-size="6" fill="#FFD700">\u2605</text>
      </svg>`}}},n={HAPPY:"happy",NORMAL:"normal",BORED:"bored",SLEEPY:"sleepy"},s={IDLE:"idle",WALK:"walk",RUN:"run",SLEEP:"sleep",JUMP:"jump",SIT:"sit",HAPPY:"happy"},v=class{constructor(t,i,l){this.id=t.id||Math.random().toString(36).slice(2),this.type=t.type||"cat",this.skin=t.skin||Object.keys(f[this.type].skins)[0],this.size=t.size||48,this.speed=t.speed||1.2,this.container=i,this.manager=l,this.x=t.x||40,this.y=0,this.vx=this.speed,this.anim=s.IDLE,this.mood=n.NORMAL,this.el=null,this.raf=null,this._typingCombo=0,this._lastType=0,this._idleTime=0,this._stateTimer=0,this._nextStateDue=3e3+Math.random()*4e3,this._jumpTimer=null,this._typeStopTimer=null,this._dragging=!1,this._dragOffX=0,this._dragOffY=0,this._dragStartX=0,this._dragStartY=0,this._tapCount=0,this._tapTimer=null,this._mount(),this._startLoop()}get colors(){return f[this.type].skins[this.skin]}get frames(){return f[this.type].frames}_mount(){this.el=document.createElement("div"),Object.assign(this.el.style,{position:"absolute",bottom:"4px",left:this.x+"px",width:this.size+"px",height:this.size+"px",zIndex:"9998",cursor:"pointer",userSelect:"none",touchAction:"none",transition:"filter 0.2s"}),this._moodEl=document.createElement("div"),Object.assign(this._moodEl.style,{position:"absolute",top:"-14px",left:"50%",transform:"translateX(-50%)",fontSize:"12px",opacity:"0",transition:"opacity 0.4s",pointerEvents:"none"}),this.el.appendChild(this._moodEl),this._render(),this._bindEvents(),this.container.appendChild(this.el)}_render(){let i=(this.frames[this.anim]||this.frames[s.IDLE])(this.colors),l=this.el.querySelector("svg");l&&l.remove();let r=document.createElement("div");r.innerHTML=i;let o=r.querySelector("svg");o&&(o.setAttribute("width",this.size),o.setAttribute("height",this.size),this.el.appendChild(o))}_bindEvents(){this.el.addEventListener("touchstart",t=>this._onTouchStart(t),{passive:!1}),this.el.addEventListener("touchmove",t=>this._onTouchMove(t),{passive:!1}),this.el.addEventListener("touchend",t=>this._onTouchEnd(t),{passive:!1}),this.el.addEventListener("mousedown",t=>this._onMouseDown(t))}_onTouchStart(t){t.preventDefault();let i=t.touches[0];this._dragStartX=i.clientX,this._dragStartY=i.clientY;let l=this.el.getBoundingClientRect();this._dragOffX=i.clientX-l.left,this._dragOffY=i.clientY-l.top,this._dragging=!1}_onTouchMove(t){t.preventDefault();let i=t.touches[0],l=Math.abs(i.clientX-this._dragStartX),r=Math.abs(i.clientY-this._dragStartY);(l>5||r>5)&&(this._dragging=!0,this._moveTo(i.clientX,i.clientY))}_onTouchEnd(t){t.preventDefault(),this._dragging||this._handleTap(),this._dragging=!1}_onMouseDown(t){let i=t.clientX,l=t.clientY,r=this.el.getBoundingClientRect();this._dragOffX=t.clientX-r.left,this._dragOffY=t.clientY-r.top;let o=p=>{let g=Math.abs(p.clientX-i),x=Math.abs(p.clientY-l);(g>5||x>5)&&(this._dragging=!0,this._moveTo(p.clientX,p.clientY))},d=()=>{document.removeEventListener("mousemove",o),document.removeEventListener("mouseup",d),this._dragging||this._handleTap(),this._dragging=!1};document.addEventListener("mousemove",o),document.addEventListener("mouseup",d)}_moveTo(t,i){let l=this.container.getBoundingClientRect(),r=t-l.left-this._dragOffX,o=i-l.top,d=this.container.offsetWidth-this.size;r=Math.max(0,Math.min(r,d)),this.x=r,this.el.style.left=r+"px",this._savePos()}_handleTap(){this._tapCount++,this._tapTimer&&clearTimeout(this._tapTimer),this._tapTimer=setTimeout(()=>{this._tapCount>=2?this._doRunBurst():this._doJump(),this._tapCount=0},280)}_doJump(){this._setAnim(s.JUMP),this._showMood("\u{1F389}"),this._jumpTimer&&clearTimeout(this._jumpTimer),this._jumpTimer=setTimeout(()=>{this._setAnim(s.IDLE)},600)}_doRunBurst(){this._setAnim(s.RUN),this.vx=this.vx>0?this.speed*4:-this.speed*4,this._showMood("\u{1F4A8}"),this._jumpTimer&&clearTimeout(this._jumpTimer),this._jumpTimer=setTimeout(()=>{this.vx=this.vx>0?this.speed:-this.speed,this._setAnim(s.WALK)},1500)}_showMood(t,i=1200){this._moodEl.textContent=t,this._moodEl.style.opacity="1",clearTimeout(this._moodHideTimer),this._moodHideTimer=setTimeout(()=>{this._moodEl.style.opacity="0"},i)}_setAnim(t){this.anim!==t&&(this.anim=t,this._render(),this.el.style.transform=this.vx<0?"scaleX(-1)":"scaleX(1)")}onType(){let t=Date.now(),i=t-this._lastType;this._lastType=t,this._idleTime=0,this._typingCombo=i<400?Math.min(this._typingCombo+1,20):1,this._typingCombo>=15?(this.mood=n.HAPPY,this._showMood("\u{1F525}",600)):this._typingCombo>=8?this.mood=n.HAPPY:this.mood=n.NORMAL,this._typingCombo>=12?(this._setAnim(s.RUN),this.vx=this.vx>0?this.speed*3:-this.speed*3):this._typingCombo>=4?(this._setAnim(s.WALK),this.vx=this.vx>0?this.speed*2:-this.speed*2):this._setAnim(s.WALK),clearTimeout(this._typeStopTimer),this._typeStopTimer=setTimeout(()=>{this._typingCombo=0,this.vx=this.vx>0?this.speed:-this.speed,this._setAnim(s.WALK)},1e3)}_startLoop(){let t=Date.now(),i=()=>{this.raf=requestAnimationFrame(i);let l=Date.now(),r=l-t;t=l,this._update(r)};this.raf=requestAnimationFrame(i)}_update(t){if(!this._dragging){if(this.anim===s.SLEEP){this._idleTime+=t;return}if(this.anim!==s.JUMP){if(this._idleTime+=t,this._stateTimer+=t,this.anim!==s.SIT&&this.anim!==s.IDLE){this.x+=this.vx;let i=this.container.offsetWidth-this.size;this.x<=0?(this.x=0,this.vx=Math.abs(this.vx),this.el.style.transform="scaleX(1)",this._maybeSocialize()):this.x>=i&&(this.x=i,this.vx=-Math.abs(this.vx),this.el.style.transform="scaleX(-1)",this._maybeSocialize()),this.el.style.left=this.x+"px"}if(this._idleTime>2e4&&this.anim!==s.SLEEP){this.mood=n.SLEEPY,this._goSleep();return}this._idleTime>1e4&&this.mood!==n.SLEEPY&&(this.mood=n.BORED,Math.random()<.001&&this._showMood("\u{1F612}")),this._stateTimer>=this._nextStateDue&&(this._stateTimer=0,this._nextStateDue=2e3+Math.random()*5e3,this._autoState())}}}_autoState(){if(this.anim===s.RUN||this.anim===s.JUMP||this._dragging)return;let t=Math.random();t<.12?(this._setAnim(s.SIT),this.vx=0,this.mood===n.HAPPY&&this._showMood("\u{1F638}"),setTimeout(()=>{this.anim===s.SIT&&(this.vx=Math.random()>.5?this.speed:-this.speed,this.el.style.transform=this.vx<0?"scaleX(-1)":"scaleX(1)",this._setAnim(s.WALK))},2e3+Math.random()*3e3)):t<.22?(this._setAnim(s.IDLE),this.vx=0,setTimeout(()=>{this.anim===s.IDLE&&(this.vx=Math.random()>.5?this.speed:-this.speed,this.el.style.transform=this.vx<0?"scaleX(-1)":"scaleX(1)",this._setAnim(s.WALK))},1e3+Math.random()*2e3)):t<.28&&this.mood===n.HAPPY?(this._setAnim(s.HAPPY),this._showMood("\u{1F496}"),setTimeout(()=>{this.anim===s.HAPPY&&this._setAnim(s.WALK)},1200)):t<.32?(this.vx=Math.random()>.5?this.speed:-this.speed,this.el.style.transform=this.vx<0?"scaleX(-1)":"scaleX(1)",this._setAnim(s.WALK)):(this.anim===s.IDLE||this.anim===s.SIT)&&(this._setAnim(s.WALK),this.vx=this.vx===0?Math.random()>.5?this.speed:-this.speed:this.vx,this.el.style.transform=this.vx<0?"scaleX(-1)":"scaleX(1)")}_goSleep(){this.vx=0,this._setAnim(s.SLEEP),this._showMood("\u{1F4A4}",3e3),setTimeout(()=>{this.anim===s.SLEEP&&(this.mood=n.NORMAL,this._idleTime=0,this.vx=Math.random()>.5?this.speed:-this.speed,this.el.style.transform=this.vx<0?"scaleX(-1)":"scaleX(1)",this._setAnim(s.WALK))},6e3+Math.random()*6e3)}_maybeSocialize(){if(!this.manager)return;let t=this.manager.pets.filter(i=>i!==this);for(let i of t)Math.abs(this.x-i.x)<60&&(this._showMood("\u{1F44B}"),i._showMood("\u{1F44B}"),this.mood=n.HAPPY,i.mood=n.HAPPY)}_savePos(){try{let t=`${y}.pos.${this.id}`;localStorage.setItem(t,JSON.stringify({x:this.x}))}catch{}}_loadPos(){try{let t=`${y}.pos.${this.id}`,i=localStorage.getItem(t);if(i){let l=JSON.parse(i);this.x=l.x||40}}catch{}}destroy(){this.raf&&cancelAnimationFrame(this.raf),clearTimeout(this._typeStopTimer),clearTimeout(this._jumpTimer),clearTimeout(this._tapTimer),clearTimeout(this._moodHideTimer),this.el?.remove()}},u=class{constructor(t){this.container=t,this.pets=[]}add(t){let i=new v(t,this.container,this);return i._loadPos(),this.pets.push(i),i}remove(t){let i=this.pets.findIndex(l=>l.id===t);i!==-1&&(this.pets[i].destroy(),this.pets.splice(i,1))}removeAll(){this.pets.forEach(t=>t.destroy()),this.pets=[]}onType(){this.pets.forEach(t=>t.onType())}};function b(e,t,i){e.settitle("Acode Pets \u{1F43E}");let l=Object.keys(f.cat.skins),r=Object.keys(f.dog.skins);e.innerHTML=`
    <style>
      .ps { padding:16px; font-family:monospace; color:var(--primary-text-color,#eee); }
      .ps-section { font-size:10px; text-transform:uppercase; letter-spacing:1px;
        opacity:.35; margin:16px 0 8px; }
      .ps-row { display:flex; align-items:center; justify-content:space-between;
        padding:10px 0; border-bottom:1px solid rgba(255,255,255,.05); gap:8px; }
      .ps-label { font-size:13px; }
      .ps-sub { font-size:11px; opacity:.4; margin-top:2px; }
      .tog { width:40px; height:22px; background:rgba(255,255,255,.12);
        border-radius:11px; position:relative; cursor:pointer;
        transition:background .2s; flex-shrink:0; }
      .tog.on { background:#50fa7b; }
      .tog::after { content:''; position:absolute; top:3px; left:3px;
        width:16px; height:16px; border-radius:50%; background:#fff;
        transition:transform .2s; }
      .tog.on::after { transform:translateX(18px); }
      .ps-chips { display:flex; flex-wrap:wrap; gap:6px; }
      .ps-chip { padding:5px 12px; background:rgba(255,255,255,.08);
        border:1px solid rgba(255,255,255,.12); border-radius:20px;
        cursor:pointer; font-size:12px; color:inherit; transition:all .2s; }
      .ps-chip.active { background:rgba(80,250,123,.2);
        border-color:#50fa7b; color:#50fa7b; }
      .ps-slider { display:flex; align-items:center; gap:10px; }
      .ps-slider input { flex:1; accent-color:#50fa7b; }
      .ps-slider span { font-size:12px; opacity:.6; min-width:28px; text-align:right; }
      .ps-add-btn { width:100%; padding:10px; margin-top:12px;
        background:rgba(80,250,123,.15); border:1px solid rgba(80,250,123,.3);
        border-radius:8px; color:#50fa7b; font-family:monospace;
        font-size:13px; cursor:pointer; }
      .ps-pet-list { margin-top:8px; }
      .ps-pet-item { display:flex; align-items:center; justify-content:space-between;
        padding:8px 0; border-bottom:1px solid rgba(255,255,255,.05); }
      .ps-del-btn { background:rgba(255,85,85,.15); border:1px solid rgba(255,85,85,.3);
        color:#ff5555; border-radius:6px; padding:3px 10px;
        font-size:11px; cursor:pointer; font-family:monospace; }
    </style>
    <div class="ps">

      <div class="ps-section">General</div>
      <div class="ps-row">
        <div><div class="ps-label">Enable Pets</div><div class="ps-sub">Show pets in editor</div></div>
        <div class="tog ${t.enabled?"on":""}" id="tog-enabled"></div>
      </div>

      <div class="ps-section">Add Pet</div>
      <div class="ps-row">
        <div><div class="ps-label">Type</div></div>
        <div class="ps-chips" id="type-chips">
          <button class="ps-chip ${t._newType==="cat"?"active":""}" data-type="cat">\u{1F431} Cat</button>
          <button class="ps-chip ${t._newType==="dog"?"active":""}" data-type="dog">\u{1F436} Dog</button>
        </div>
      </div>
      <div class="ps-row" id="skin-row">
        <div><div class="ps-label">Skin</div></div>
        <div class="ps-chips" id="skin-chips"></div>
      </div>
      <div class="ps-row">
        <div><div class="ps-label">Size</div><div class="ps-sub">Pet size in px</div></div>
        <div class="ps-slider">
          <input type="range" id="size-range" min="32" max="96" value="${t._newSize||48}">
          <span id="size-val">${t._newSize||48}</span>
        </div>
      </div>
      <div class="ps-row">
        <div><div class="ps-label">Speed</div><div class="ps-sub">Movement speed</div></div>
        <div class="ps-slider">
          <input type="range" id="speed-range" min="1" max="5" step="0.5" value="${t._newSpeed||1.2}">
          <span id="speed-val">${t._newSpeed||1.2}</span>
        </div>
      </div>
      <button class="ps-add-btn" id="add-btn">+ Add Pet</button>

      <div class="ps-section">Active Pets</div>
      <div class="ps-pet-list" id="pet-list"></div>

    </div>`;function o(c){let a=Object.keys(f[c].skins),m=e.querySelector("#skin-chips");m.innerHTML=a.map(h=>`<button class="ps-chip ${t._newSkin===h?"active":""}" data-skin="${h}">${h}</button>`).join(""),m.querySelectorAll(".ps-chip").forEach(h=>{h.addEventListener("click",()=>{t._newSkin=h.dataset.skin,m.querySelectorAll(".ps-chip").forEach(_=>_.classList.remove("active")),h.classList.add("active")})})}o(t._newType||"cat");function d(){let c=e.querySelector("#pet-list");if(!t.pets||!t.pets.length){c.innerHTML='<div style="opacity:.4;font-size:12px;padding:8px 0">No pets yet \u2014 add one above!</div>';return}c.innerHTML=t.pets.map(a=>`
      <div class="ps-pet-item">
        <div>
          <span style="font-size:13px">${a.type==="cat"?"\u{1F431}":"\u{1F436}"} ${a.type} \xB7 ${a.skin}</span>
          <span style="font-size:11px;opacity:.4;margin-left:8px">${a.size||48}px</span>
        </div>
        <button class="ps-del-btn" data-id="${a.id}">Remove</button>
      </div>
    `).join(""),c.querySelectorAll(".ps-del-btn").forEach(a=>{a.addEventListener("click",()=>{t.pets=t.pets.filter(m=>m.id!==a.dataset.id),i(t),d()})})}d(),e.querySelector("#tog-enabled").addEventListener("click",function(){t.enabled=!t.enabled,this.classList.toggle("on",t.enabled),i(t)}),e.querySelectorAll("#type-chips .ps-chip").forEach(c=>{c.addEventListener("click",()=>{t._newType=c.dataset.type,t._newSkin=Object.keys(f[c.dataset.type].skins)[0],e.querySelectorAll("#type-chips .ps-chip").forEach(a=>a.classList.remove("active")),c.classList.add("active"),o(c.dataset.type)})});let p=e.querySelector("#size-range"),g=e.querySelector("#size-val");p.addEventListener("input",()=>{t._newSize=parseInt(p.value),g.textContent=p.value});let x=e.querySelector("#speed-range"),w=e.querySelector("#speed-val");x.addEventListener("input",()=>{t._newSpeed=parseFloat(x.value),w.textContent=x.value}),e.querySelector("#add-btn").addEventListener("click",()=>{t.pets||(t.pets=[]),t.pets.push({id:Math.random().toString(36).slice(2),type:t._newType||"cat",skin:t._newSkin||"orange",size:t._newSize||48,speed:t._newSpeed||1.2}),i(t),d()})}var k=class{constructor(){this.settings=this._load(),this._manager=null,this._listener=null,this.$page=null}async init(t,i,{firstInit:l}){this.$page=i;let r=editorManager.container;getComputedStyle(r).position==="static"&&(r.style.position="relative"),this._manager=new u(r),this.settings.enabled&&this._spawnAll(),this._listener=()=>{this._manager&&this._manager.onType()},editorManager.on("file-content-changed",this._listener),acode.require("commands").addCommand({name:"acode-pets:settings",description:"Acode Pets: Settings",exec:()=>{b(this.$page,this.settings,d=>{this.settings=d,this._save(),this._manager.removeAll(),d.enabled&&this._spawnAll()}),this.$page.show()}}),l&&(!this.settings.pets||!this.settings.pets.length)&&(this.settings.pets=[{id:"default",type:"cat",skin:"orange",size:48,speed:1.2}],this._save(),this._spawnAll())}_spawnAll(){this.settings.pets&&this.settings.pets.forEach(t=>this._manager.add(t))}_save(){try{localStorage.setItem(y+".s",JSON.stringify(this.settings))}catch{}}_load(){try{let t=localStorage.getItem(y+".s");if(t)return JSON.parse(t)}catch{}return{enabled:!0,pets:[],_newType:"cat",_newSkin:"orange",_newSize:48,_newSpeed:1.2}}async destroy(){this._manager&&this._manager.removeAll(),this._listener&&(editorManager.off("file-content-changed",this._listener),this._listener=null),acode.require("commands").removeCommand("acode-pets:settings")}};if(window.acode){let e=new k;acode.setPluginInit(y,(t,i,l)=>e.init(t,i,l)),acode.setPluginUnmount(y,()=>e.destroy())}})();
